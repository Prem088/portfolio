import React from 'react'
import Hero from '../components/Hero'
import Services from '../components/Services'
import Portfolio from '../components/Portfolio'
import CaseStudies from '../components/CaseStudies'
import Contact from '../components/Contact'
import HowItWorks from '../components/HowItWorks'

export default function Home() {
  return (
    <>
      <Hero />
      <Services />
      <HowItWorks />
      <Portfolio />   {/* ✅ FIXED */}
      <CaseStudies />
      <Contact />
    </>
  )
}