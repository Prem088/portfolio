import React from 'react'
import { Navigate, useParams } from 'react-router-dom'
import { motion } from 'framer-motion'
import { caseStudyRoutes } from '../data/caseStudies'
import '../styles/CaseStudyPage.css'

export default function CaseStudyPage() {
  const { slug } = useParams()
  const study = caseStudyRoutes[slug]

  if (!study) {
    return <Navigate to="/" replace />
  }

  return (
    <main className="case-study-page">
      <section className="case-study-hero section">
        <div className="container">
          <motion.div
            className="case-study-hero-card card"
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            <div className="case-study-hero-badge">{study.tag}</div>
            <h1>{study.title}</h1>
            <p className="case-study-subtitle">{study.shortDescription}</p>

            <div className="tech-pills">
              {study.techStack.map((tech) => (
                <span key={tech} className="tech-pill">
                  {tech}
                </span>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      <section className="section case-study-content">
        <div className="container case-study-grid">
          <motion.div
            className="case-study-main"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55 }}
            viewport={{ once: true }}
          >
            <div className="case-section card">
              <h2>Overview</h2>
              <p>{study.overview}</p>
            </div>

            <div className="case-section card">
              <h2>Problem</h2>
              <p>{study.problem}</p>
            </div>

            <div className="case-section card">
              <h2>Solution</h2>
              <p>{study.solution}</p>
            </div>

            <div className="case-section card">
              <h2>System Workflow / Process</h2>
              <ol className="workflow-list">
                {study.workflow.map((step, index) => (
                  <li key={step}>
                    <span className="workflow-step">{index + 1}</span>
                    <span>{step}</span>
                  </li>
                ))}
              </ol>
            </div>

            <div className="case-section card">
              <h2>Key Features</h2>
              <ul className="feature-list">
                {study.features.map((feature) => (
                  <li key={feature}>
                    <span className="feature-marker">✓</span>
                    <span>{feature}</span>
                  </li>
                ))}
              </ul>
            </div>

            <div className="case-section card">
              <h2>Result</h2>
              <p>{study.result}</p>
            </div>
          </motion.div>

          <motion.aside
            className="case-study-sidebar card"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55, delay: 0.1 }}
            viewport={{ once: true }}
          >
            <div className="sidebar-image" style={{ background: study.imageBg }}>
              <span className="sidebar-emoji">{study.emoji}</span>
            </div>

            <div className="sidebar-block">
              <span className="sidebar-label">Tech Stack</span>
              <p>{study.techStack.join(' • ')}</p>
            </div>

            <div className="sidebar-block">
              <span className="sidebar-label">Project Focus</span>
              <p>{study.tag}</p>
            </div>

            <div className="sidebar-block">
              <span className="sidebar-label">CTA</span>
              <p>Looking to build a system for your business?
Let’s discuss your project requirements.</p>
              <motion.a
                href="/#contact"
                className="btn btn-primary sidebar-cta-btn"
                whileHover={{ scale: 1.03, y: -2 }}
                whileTap={{ scale: 0.97 }}
              >
                Start Project →
              </motion.a>
            </div>
          </motion.aside>
        </div>
      </section>

      <section className="section case-study-cta-section">
        <div className="container">
          <motion.div
            className="case-study-cta card"
            initial={{ opacity: 0, y: 24 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.55 }}
            viewport={{ once: true }}
          >
            <div>
              <h2>Start a Project</h2>
              <p>
                Want a similar product built for your business? Let’s discuss the scope and
                timeline.
              </p>
            </div>

            <motion.a
              href="/#contact"
              className="btn btn-primary"
              whileHover={{ scale: 1.03, y: -2 }}
              whileTap={{ scale: 0.97 }}
            >
              Start Project →
            </motion.a>
          </motion.div>

          <div className="case-study-back-link">
            <a href="/#projects">Back to Projects</a>
          </div>
        </div>
      </section>
    </main>
  )
}
