export const caseStudies = [
  {
    slug: 'medical-vendor',
    title: 'Medical Vendor Management System',
    tag: 'Management System',
    description:
      'Built to manage vendor and inventory workflows. Developed as a real-world system to manage business workflows efficiently.',
    shortDescription:
      'A web-based management system developed to organize vendors, inventory, and purchase workflows.',
    overview:
      'This project was developed as a practical implementation of a real-world workflow. It demonstrates how vendor, stock, and purchasing records can be managed through a structured process.',
    summaryProblem:
      'Manual vendor tracking created stock errors and made purchasing harder to manage.',
    problem:
      'Manual vendor and inventory tracking caused errors, slowed purchasing, and made stock management difficult for the team.',
    solution:
      'I developed a system using PHP, MySQL, JavaScript, and Bootstrap to manage vendors, inventory, and purchase workflows in one place.',
    workflow: [
      'Map vendor, stock, and purchase data into clear modules.',
      'Build the admin flow for inventory updates and purchase creation.',
      'Add reporting views for quick operational decisions.',
      'Validate records and finalize the handoff for daily use.',
    ],
    features: [
      'Vendor and supplier management',
      'Real-time inventory tracking',
      'Purchase and order management',
      'Admin dashboard with reporting',
    ],
    result:
      'Demonstrates improved workflow efficiency and reduced manual effort through structured vendor and inventory handling.',
    techStack: ['PHP', 'MySQL', 'JavaScript', 'Bootstrap'],
    imageBg: 'linear-gradient(135deg, #0f1b33, #1a2f50)',
    emoji: '🏥',
    featured: true,
    color: 'primary',
  },
  {
    slug: 'hotel-system',
    title: 'Hotel Management System',
    tag: 'Booking System',
    description:
      'Built to manage bookings, customer records, and billing. Developed as a real-world system to manage business workflows efficiently.',
    shortDescription:
      'A web-based hotel management system developed to handle bookings, customer records, and billing operations.',
    overview:
      'This project was developed as a practical implementation of a real-world workflow. It demonstrates how booking, customer management, and billing can be handled in a single system.',
    summaryProblem:
      'Manual booking and billing work caused delays and errors in day-to-day operations.',
    problem:
      'Manual booking, billing, and customer management caused delays and errors during day-to-day hotel operations.',
    solution:
      'I developed a system using ASP.NET, C#, and SQL Server to manage room booking, customer records, and billing workflows.',
    workflow: [
      'Define room, booking, and customer records.',
      'Build availability and reservation management.',
      'Connect billing and invoice generation flows.',
      'Test the booking lifecycle end to end.',
    ],
    features: [
      'Room booking and availability tracking',
      'Customer record management',
      'Billing and invoice generation',
      'Operational dashboard views',
    ],
    result:
      'Demonstrates improved workflow efficiency and reduced manual effort in booking and billing operations.',
    techStack: ['ASP.NET', 'C#', 'SQL Server'],
    imageBg: 'linear-gradient(135deg, #1a1040, #2a1a5e)',
    emoji: '🏨',
    featured: false,
    color: 'secondary',
  },
  {
    slug: 'food-ordering',
    title: 'Food Ordering System',
    tag: 'Ordering System',
    description:
      'Built to manage menu browsing, ordering, and checkout. Developed as a real-world system to manage business workflows efficiently.',
    shortDescription:
      'Web-based platform for browsing menus and placing food orders online.',
    overview:
      'This project was developed as a practical implementation of a real-world workflow. It demonstrates how customer ordering and order tracking can be organized in one web-based system.',
    summaryProblem:
      'Customers lacked a simple way to browse menus and place orders online.',
    problem:
      'Customers had no simple way to browse menus and place orders online, which limited convenience and slowed ordering.',
    solution:
      'I developed a system using PHP, MySQL, JavaScript, and Bootstrap to manage menu browsing, checkout, and order tracking.',
    workflow: [
      'Plan the menu, cart, and checkout flow.',
      'Implement customer ordering and admin management.',
      'Connect order tracking and status handling.',
      'Review the flow for fast mobile-friendly ordering.',
    ],
    features: [
      'Menu browsing and selection',
      'Cart and checkout system',
      'Order management dashboard',
      'Responsive customer flow',
    ],
    result:
      'Demonstrates improved workflow efficiency and reduced manual effort in day-to-day order handling.',
    techStack: ['PHP', 'MySQL', 'JavaScript', 'Bootstrap'],
    imageBg: 'linear-gradient(135deg, #0d2020, #0d3a30)',
    emoji: '🍔',
    featured: false,
    color: 'tertiary',
  },
  {
    slug: 'ai-task',
    title: 'AI Task Management System',
    tag: 'AI Application',
    description:
      'Built to organize tasks with AI-assisted prioritization. Developed as a real-world system to manage business workflows efficiently.',
    shortDescription:
      'Full-stack task management system with workflow control, dashboard analytics, and AI-assisted productivity features.',
    overview:
      'This project was developed as a practical implementation of a real-world workflow. It demonstrates how task tracking and AI-assisted prioritization can improve planning clarity.',
    summaryProblem:
      'Users needed a better way to organize tasks and prioritize daily work.',
    problem:
      'Users found it difficult to manage tasks effectively and lacked intelligent suggestions for prioritization.',
    solution:
      'I developed a system using React, ASP.NET Core, and MySQL to manage task tracking and AI-assisted prioritization.',
    workflow: [
      'Structure tasks, statuses, and dashboard views.',
      'Build the task flow and analytics screens.',
      'Add AI-assisted recommendations for prioritization.',
      'Refine the workflow for clarity and daily use.',
    ],
    features: [
      'Task creation and tracking',
      'AI-based recommendations',
      'Interactive dashboard interface',
      'Workflow visibility for daily planning',
    ],
    result:
      'Demonstrates improved workflow efficiency and reduced manual effort in organizing and prioritizing tasks.',
    techStack: ['React', 'ASP.NET Core', 'MySQL', 'AI-Assisted'],
    imageBg: 'linear-gradient(135deg, #1a0f20, #2e1540)',
    emoji: '🤖',
    featured: true,
    color: 'primary',
  },
  {
    slug: 'health-chatbot',
    title: 'Health Chatbot System',
    tag: 'Chatbot System',
    description:
      'Built to handle common health queries through chatbot flows. Developed as a real-world system to manage business workflows efficiently.',
    shortDescription:
      'NLP-based chatbot providing quick health-related guidance.',
    overview:
      'This project was developed as a practical implementation of a real-world workflow. It demonstrates how common health questions can be handled through a lightweight chatbot interface.',
    summaryProblem:
      'Users needed quick access to basic health guidance in a simple format.',
    problem:
      'Users needed quick access to basic health guidance but lacked a simple and accessible solution.',
    solution:
      'I developed a system using PHP and NLP logic to handle common health-related queries through a chatbot interface.',
    workflow: [
      'Define the most common health questions and response patterns.',
      'Build the chatbot interface and reply logic.',
      'Map NLP intents to useful guidance responses.',
      'Test the conversation flow for clarity and speed.',
    ],
    features: [
      'Interactive chatbot interface',
      'NLP-based response system',
      'Basic health query handling',
      'Fast response flow',
    ],
    result:
      'Demonstrates improved workflow efficiency and reduced manual effort in handling repetitive health guidance queries.',
    techStack: ['PHP', 'NLP'],
    imageBg: 'linear-gradient(135deg, #1f1500, #332200)',
    emoji: '💬',
    featured: false,
    color: 'secondary',
  },
  {
    slug: 'solar-system',
    title: '3D Solar System Simulation',
    tag: 'JavaScript Project',
    description:
      'Built to demonstrate planetary motion with interactive visuals. Developed as a real-world system to manage business workflows efficiently.',
    shortDescription:
      'Interactive 3D simulation of planetary motion using JavaScript.',
    overview:
      'This project was developed as a practical implementation of a real-world workflow. It demonstrates how motion and visualization logic can be presented through an interactive 3D model.',
    summaryProblem:
      'Planetary motion was hard to understand without an interactive visual tool.',
    problem:
      'Understanding planetary motion was difficult due to the lack of interactive learning tools.',
    solution:
      'I developed a system using JavaScript animation logic to represent planetary motion through an interactive 3D simulation.',
    workflow: [
      'Lay out the solar system and motion model.',
      'Create the animated orbit and rotation behavior.',
      'Tune the visual experience for clarity and motion.',
      'Validate the simulation for smooth interaction.',
    ],
    features: [
      '3D planet rotation and motion',
      'Real-time animation rendering',
      'Interactive visualization',
      'Educational motion model',
    ],
    result:
      'Demonstrates improved workflow efficiency in presenting planetary concepts with reduced manual explanation effort.',
    techStack: ['JavaScript', 'Animation'],
    imageBg: 'linear-gradient(135deg, #0b1f3a, #162f5e)',
    emoji: '🌌',
    featured: false,
    color: 'tertiary',
  },
  {
    slug: 'school-ui',
    title: 'School Management System UI',
    tag: 'UI Design',
    description:
      'Built to manage school workflows with a responsive dashboard. Developed as a real-world system to manage business workflows efficiently.',
    shortDescription:
      'Modern dashboard UI design for school management systems.',
    overview:
      'This project was developed as a practical implementation of a real-world workflow. It demonstrates how school management tasks can be organized through a modern dashboard UI.',
    summaryProblem:
      'Existing school systems used outdated interfaces that were hard to manage.',
    problem:
      'Existing school systems had outdated interfaces, making them difficult to use and manage.',
    solution:
      'I developed a system interface using React to manage school-related workflows with clear structure and responsive behavior.',
    workflow: [
      'Map the school admin workflow and dashboard hierarchy.',
      'Design clean responsive screens for the core tasks.',
      'Refine navigation and usability for school staff.',
      'Check the UI across mobile and desktop sizes.',
    ],
    features: [
      'Clean and structured dashboard layout',
      'Responsive design across devices',
      'User-friendly interface design',
      'Simple navigation for school workflows',
    ],
    result:
      'Demonstrates improved workflow efficiency and reduced manual effort through a clearer dashboard interaction flow.',
    techStack: ['React', 'UI Design'],
    imageBg: 'linear-gradient(135deg, #2a1a5e, #4c2c8a)',
    emoji: '🎓',
    featured: false,
    color: 'primary',
  },
]

export const caseStudyRoutes = caseStudies.reduce((routes, study) => {
  routes[study.slug] = study
  return routes
}, {})
