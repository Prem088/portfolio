import React, { useState, useEffect } from 'react'
import { useLocation } from 'react-router-dom'
import { motion } from 'framer-motion'
import './Navbar.css'
import { label } from 'framer-motion/client'
import logo from '../assets/logo2.png'

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false)
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)
  const { pathname } = useLocation()

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const menuItems = [
    { label: 'Projects', href: '#projects' },
    { label: 'How I Work', href: '#process' },
    { label: 'Case Studies', href: '#case-studies' },
    { label: 'Contact', href: '#contact' },
  ]

  const resolveSectionHref = (href) => (pathname === '/' ? href : `/${href}`)

  return (
    <motion.nav
      className={`navbar ${isScrolled ? 'scrolled' : ''}`}
      initial={{ opacity: 0, y: -100 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.6 }}
    >
      <div className="navbar-container">
        <motion.a
          href="#"
          className="navbar-logo"
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <img src={logo} alt="Prem Bansal Logo" className="nav-logo" />
        </motion.a>

        <motion.ul className="navbar-menu" initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ delay: 0.3 }}>
          {menuItems.map((item, i) => (
            <motion.li key={item.label} initial={{ opacity: 0, y: -10 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 + i * 0.1 }}>
              <motion.a href={resolveSectionHref(item.href)} className="nav-link" whileHover={{ y: -2 }} transition={{ type: 'spring', stiffness: 300 }}>
                {item.label}
                <span className="nav-link-underline"></span>
              </motion.a>
            </motion.li>
          ))}
        </motion.ul>

        <motion.div className="navbar-actions" initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.5 }}>
          <motion.a href="mailto:prembansal088@gmail.com" className="nav-action-link" whileHover={{ y: -2 }} title="Email">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z" /><polyline points="22,6 12,13 2,6" /></svg>
            <span>Email</span>
          </motion.a>
          <motion.a href="https://github.com/Prem088" className="nav-action-link" target="_blank" rel="noopener noreferrer" whileHover={{ y: -2 }} title="GitHub">
            <svg width="15" height="15" viewBox="0 0 24 24" fill="currentColor"><path d="M12 0C5.374 0 0 5.373 0 12c0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23A11.509 11.509 0 0 1 12 5.803c1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576C20.566 21.797 24 17.3 24 12c0-6.627-5.373-12-12-12z" /></svg>
            <span>GitHub</span>
          </motion.a>
          <motion.a href="/#contact" className="btn btn-call-nav" whileHover={{ scale: 1.05, y: -2 }} whileTap={{ scale: 0.95 }}>
            <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M22 16.92v3a2 2 0 01-2.18 2 19.79 19.79 0 01-8.63-3.07A19.5 19.5 0 013.07 9.81a19.79 19.79 0 01-3.07-8.67A2 2 0 012.18 1h3a2 2 0 012 1.72c.127.96.361 1.903.7 2.81a2 2 0 01-.45 2.11L6.91 8.09a16 16 0 006 6l1.46-1.46a2 2 0 012.11-.45c.907.339 1.85.573 2.81.7A2 2 0 0122 14.92z" /></svg>
            Start Project
          </motion.a>
        </motion.div>

        <motion.button className={`mobile-menu-toggle ${isMobileMenuOpen ? 'active' : ''}`} onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)} whileTap={{ scale: 0.9 }}>
          <span></span><span></span><span></span>
        </motion.button>
      </div>

      <motion.div className={`mobile-menu ${isMobileMenuOpen ? 'open' : ''}`} initial={{ opacity: 0, height: 0 }} animate={{ opacity: isMobileMenuOpen ? 1 : 0, height: isMobileMenuOpen ? 'auto' : 0 }} transition={{ duration: 0.3 }}>
        {menuItems.map((item, index) => (
          <motion.a key={item.label} href={resolveSectionHref(item.href)} className="mobile-nav-link" onClick={() => setIsMobileMenuOpen(false)} initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: index * 0.05 }}>{item.label}</motion.a>
        ))}
        <div className="mobile-actions">
          <a href="mailto:prembansal088@gmail.com" className="mobile-nav-link" onClick={() => setIsMobileMenuOpen(false)}>✉ Email</a>
          <a href="https://github.com/Prem088" className="mobile-nav-link" target="_blank" rel="noopener noreferrer" onClick={() => setIsMobileMenuOpen(false)}>⌥ GitHub</a>
          <a href="tel:+91 9409980740" className="btn btn-call-nav mobile-cta" onClick={() => setIsMobileMenuOpen(false)}>📞 Call Me</a>
        </div>
      </motion.div>
    </motion.nav>
  )
}
