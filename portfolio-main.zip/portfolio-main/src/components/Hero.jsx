import React from 'react'
import { motion } from 'framer-motion'
import './Hero.css'


export default function Hero() {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: { staggerChildren: 0.18, delayChildren: 0.15 },
    },
  }

  const itemVariants = {
    hidden: { opacity: 0, y: 32 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { type: 'spring', stiffness: 55, damping: 12 },
    },
  }

  return (
    <section className="hero" id="home">
      <div className="hero-bg">
        <motion.div className="blob blob-1" animate={{ y: [0, -20, 0], opacity: [0.25, 0.45, 0.25] }} transition={{ duration: 9, repeat: Infinity, ease: 'easeInOut' }} />
        <motion.div className="blob blob-2" animate={{ y: [0, 20, 0], opacity: [0.15, 0.35, 0.15] }} transition={{ duration: 11, repeat: Infinity, ease: 'easeInOut' }} />
        <motion.div className="blob blob-3" animate={{ y: [0, -14, 0], opacity: [0.2, 0.38, 0.2] }} transition={{ duration: 13, repeat: Infinity, ease: 'easeInOut' }} />
      </div>

      <div className="hero-content">
        <motion.div className="hero-text" variants={containerVariants} initial="hidden" animate="visible">

          <motion.div className="hero-badge" variants={itemVariants}>
            <span className="badge-dot"></span>
            <span>Available for freelance work • Open to new projects</span>
          </motion.div>

      <motion.h1 className="hero-title" variants={itemVariants}>
  I build scalable <span className="gradient-text">business systems</span> & web applications that streamline workflows and reduce manual effort
</motion.h1>

<motion.p className="hero-subtitle" variants={itemVariants}>
  Focused on building admin panels, dashboards, and systems that help businesses operate more efficiently.
</motion.p>
          <motion.div className="hero-buttons" variants={itemVariants}>
            <motion.a
              href="#projects"
              className="btn btn-primary"
              whileHover={{ scale: 1.04, y: -3 }}
              whileTap={{ scale: 0.96 }}
            >
              View My Work
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>
            </motion.a>
            <motion.a
              href="/#contact"
              className="btn btn-secondary"
              whileHover={{ scale: 1.04, y: -3 }}
              whileTap={{ scale: 0.96 }}
            >
              Start a Project
            </motion.a>
          </motion.div>
<motion.div 
  className="hero-trust"
  variants={itemVariants}
>
  <p>✔ Built multiple real-world system projects</p>
  <p>✔ Focused on business workflows & automation</p>
</motion.div>
         <motion.div className="hero-tech-strip" variants={itemVariants}>
  {['ASP.NET', 'C#', 'SQL', 'PHP', 'JavaScript','WordPress'].map((tech) => (
    <span key={tech} className="tech-chip">{tech}</span>
  ))}
</motion.div>
        </motion.div>

        <motion.div
          className="hero-visual"
          initial={{ opacity: 0, x: 40 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.5, duration: 0.8 }}
        >
          <motion.div
            className="hero-image-wrapper"
            animate={{ y: [0, -10, 0] }}
            transition={{ duration: 4.5, repeat: Infinity, ease: 'easeInOut' }}
          >
            <div className="hero-code-card">
              <div className="code-card-header">
                <span className="dot red"></span>
                <span className="dot yellow"></span>
                <span className="dot green"></span>
                <span className="code-card-title">project.config.js</span>
              </div>
              <div className="code-card-body">
  <div className="code-line">
    <span className="code-keyword">const</span>{' '}
    <span className="code-var">project</span>{' '}
    <span className="code-op">=</span> {'{'}
  </div>

  <div className="code-line indent">
    <span className="code-prop">stack</span>
    <span className="code-op">:</span>{' '}
    <span className="code-str">'ASP.NET / PHP / SQL'</span>
    <span className="code-op">,</span>
  </div>

  <div className="code-line indent">
    <span className="code-prop">type</span>
    <span className="code-op">:</span>{' '}
    <span className="code-str">'Business Application'</span>
    <span className="code-op">,</span>
  </div>

  <div className="code-line indent">
    <span className="code-prop">focus</span>
    <span className="code-op">:</span>{' '}
    <span className="code-str">'Management Systems'</span>
    <span className="code-op">,</span>
  </div>

  <div className="code-line indent">
    <span className="code-prop">status</span>
    <span className="code-op">:</span>{' '}
    <span className="code-str">'Completed Projects'</span>
    <span className="code-op">,</span>
  </div>

  <div className="code-line indent">
    <span className="code-prop">quality</span>
    <span className="code-op">:</span>{' '}
    <span className="code-str">'Clean & Scalable'</span>
    <span className="code-op">,</span>
  </div>

  <div className="code-line">{'}'}</div>
</div>
            </div>
          </motion.div>

        <motion.div className="floating-card card-1" animate={{ y: [0, -18, 0], rotate: [0, 4, 0] }} transition={{ duration: 5.5, repeat: Infinity }}>
  <span className="floating-icon">⚙️</span> ASP.NET
</motion.div>

<motion.div className="floating-card card-2" animate={{ y: [0, 18, 0], rotate: [0, -4, 0] }} transition={{ duration: 6.5, repeat: Infinity }}>
  <span className="floating-icon">🗄️</span> SQL Systems
</motion.div>

<motion.div className="floating-card card-3" animate={{ y: [0, -12, 0], rotate: [0, 3, 0] }} transition={{ duration: 7.5, repeat: Infinity }}>
  <span className="floating-icon">📊</span> Dashboards
</motion.div>
        </motion.div>
      </div>

      <motion.div className="scroll-indicator" animate={{ y: [0, 10, 0] }} transition={{ duration: 2.2, repeat: Infinity }}>
        <span>Scroll to explore</span>
        <div className="mouse-wheel"><div className="wheel"></div></div>
      </motion.div>
    </section>
  )
}
