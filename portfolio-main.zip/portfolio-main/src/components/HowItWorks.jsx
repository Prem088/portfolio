import React from 'react'
import { motion } from 'framer-motion'
import './HowItWorks.css'

const steps = [
  {
    id: 1,
    title: 'Discuss Requirements',
    desc: 'You share your project idea or requirements. I understand your needs and suggest the best solution.',
  },
  {
    id: 2,
    title: 'Planning & Design',
    desc: 'I plan the system structure, features, and user flow to ensure smooth development.',
  },
  {
    id: 3,
    title: 'Development',
    desc: 'I build your application using clean and scalable code with regular updates.',
  },
  {
    id: 4,
    title: 'Delivery & Support',
    desc: 'Project is delivered with testing, and I provide support for improvements or fixes.',
  },
]

export default function HowItWorks() {
  return (
    <section className="how section" id="process">
      <div className="container">

        <motion.div
          className="section-title"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
        >
          <h2>How I Work</h2>
          <p>A simple process to turn your idea into a working product</p>
        </motion.div>

        <div className="how-grid">
          {steps.map((step, index) => (
            <motion.div
              key={step.id}
              className="how-card"
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ delay: index * 0.1 }}
            >
              <div className="how-number">{step.id}</div>
              <h3>{step.title}</h3>
              <p>{step.desc}</p>
            </motion.div>
          ))}
        </div>

      </div>
    </section>
  )
}