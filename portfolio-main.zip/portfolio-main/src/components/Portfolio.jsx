import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { caseStudies } from '../data/caseStudies'
import './Portfolio.css'

const MotionLink = motion(Link)

export default function Portfolio() {
  return (
    <section className="portfolio section" id="projects">
      <div className="container">
        <motion.div
          className="section-title"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2>My Projects</h2>
          <p>A selection of real-world systems and implementation projects</p>
        </motion.div>

        <div className="projects-grid">
          {caseStudies.map((project, index) => (
            <motion.div
              key={project.slug}
              className={`project-card ${project.featured ? 'featured' : ''}`}
              initial={{ opacity: 0, y: 28 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.09 }}
              viewport={{ once: true }}
              whileHover={{ y: -6 }}
            >
              <div className="project-image" style={{ background: project.imageBg }}>
                <span className="project-emoji">{project.emoji}</span>
                {project.featured && <span className="featured-badge">Featured</span>}
              </div>

            <div className="project-content">
  <h3 className="project-title">{project.title}</h3>

  <p className="project-description">
    {project.description}
  </p>

  {/* TECH TAGS */}
  <div className="project-tags">
    {project.techStack.map((tag, idx) => (
      <span key={idx} className="project-tag">
        {tag}
      </span>
    ))}
  </div>

  {/* ACTION BUTTONS */}
  <div className="project-actions">

  {project.projectLink ? (
    <>
      <motion.a
        href={project.projectLink}
        className="btn btn-primary btn-sm"
        whileHover={{ y: -2 }}
        whileTap={{ scale: 0.96 }}
      >
        View Project
      </motion.a>

      <motion.a
        href={project.caseStudy}
        className="btn btn-secondary btn-sm"
        whileHover={{ y: -2 }}
        whileTap={{ scale: 0.96 }}
      >
        Case Study
      </motion.a>
    </>
  ) : (
    <>
      <MotionLink
        to={`/case-study/${project.slug}`}
        className="btn btn-primary btn-sm"
        whileHover={{ y: -2 }}
        whileTap={{ scale: 0.96 }}
      >
        View Full Case Study →
      </MotionLink>

      <motion.a
        href="#contact"
        className="btn btn-outline btn-sm"
        whileHover={{ y: -2 }}
        whileTap={{ scale: 0.96 }}
      >
        Request Access
      </motion.a>
    </>
  )}

</div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  )
}
