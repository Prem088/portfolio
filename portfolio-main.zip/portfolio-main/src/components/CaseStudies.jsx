import React from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'framer-motion'
import { caseStudies } from '../data/caseStudies'
import './CaseStudies.css'

const MotionLink = motion(Link)

export default function CaseStudies() {
  return (
    <section className="case-studies section light" id="case-studies">
      <div className="container">
        <motion.div
          className="section-title"
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.6 }}
          viewport={{ once: true }}
        >
          <h2>Case Studies</h2>
          <p>How I approach real problems and deliver measurable results</p>
        </motion.div>

        <div className="case-studies-list">
          {caseStudies.map((cs, index) => (
            <motion.div
              key={cs.slug}
              className={`case-card color-${cs.color}`}
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, delay: index * 0.1 }}
              viewport={{ once: true }}
              whileHover={{ y: -6 }}
            >
              <div className="case-card-header">
                <span className="case-tag">{cs.tag}</span>
                <h3 className="case-title">{cs.title}</h3>
              </div>

              <p className="case-tech">{cs.techStack.join(' • ')}</p>

              <div className="case-body">
                <div className="case-block">
                  <span className="case-label">Problem</span>
                  <p className="case-text">{cs.summaryProblem}</p>
                </div>

                <div className="case-block">
                  <span className="case-label">Key Features</span>
                  <ul className="case-features">
                    {cs.features.slice(0, 3).map((f, i) => (
                      <li key={i}>
                        <span className="case-check">✓</span>
                        {f}
                      </li>
                    ))}
                  </ul>
                </div>

                <div className="case-result-block">
                  <span className="result-label">📈 Result</span>
                  <p className="result-text">{cs.result}</p>
                </div>

                <MotionLink
                  to={`/case-study/${cs.slug}`}
                  className="btn btn-secondary btn-sm case-study-btn"
                  whileHover={{ y: -2 }}
                  whileTap={{ scale: 0.96 }}
                >
                  View Full Case Study →
                </MotionLink>
              </div>
            </motion.div>
          ))}
        </div>

        <motion.div
          className="case-studies-cta"
          initial={{ opacity: 0, y: 24 }}
          whileInView={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.55 }}
          viewport={{ once: true }}
        >
          <p>Looking to build a system for your business?</p>
          <motion.a
            href="/#contact"
            className="btn btn-primary"
            whileHover={{ scale: 1.03, y: -2 }}
            whileTap={{ scale: 0.97 }}
          >
            Start a Project →
          </motion.a>
        </motion.div>
      </div>
    </section>
  )
}
